﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Obchod
{
    internal class PolozkaObchodu
    {
        public double cenaZaMernouJednotku { get; set; }
        public double pocet { get; }
        public string mernaJednotka { get; set; }
        private string nazev;
        
        public string Nazev
        {
            get { return nazev; }
            set { nazev = value; }
        }


        public PolozkaObchodu(double cenaZaMernouJednotku, double pocet, string mernaJednotka, string nazev)
        {
            this.cenaZaMernouJednotku = cenaZaMernouJednotku;
            this.pocet = pocet;
            this.mernaJednotka = mernaJednotka;
            this.nazev = nazev;
        }

        public double celkovaCena()
        {
            return cenaZaMernouJednotku * pocet;
        }
    }
}
