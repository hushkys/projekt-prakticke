﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Obchod
{
    internal class Obchod
    {
        private LinkedList<PolozkaObchodu> polozkyObchodu;
        private string nazevObchodu;

        public Obchod(string nazevObchodu)
        {
            this.polozkyObchodu = new LinkedList<PolozkaObchodu>();
            this.nazevObchodu = nazevObchodu;
        }
        public Obchod(LinkedList<PolozkaObchodu> polozkyObchodu, string nazevObchodu)
        {
            this.polozkyObchodu = polozkyObchodu;
            this.nazevObchodu = nazevObchodu;
        }

        public void pridejPolozku(PolozkaObchodu polozkaObchodu)
        {
            if(polozkyObchodu.Contains(polozkaObchodu) == false)
            polozkyObchodu.AddLast(polozkaObchodu);
        }
        public void odeberPolozku(PolozkaObchodu polozkaObchodu)
        {
            if(polozkyObchodu.Contains(polozkaObchodu) == true)
                polozkyObchodu.Remove(polozkaObchodu);
        }
    }
}
