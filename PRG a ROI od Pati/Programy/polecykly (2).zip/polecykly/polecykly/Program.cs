﻿namespace polecykly
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //cast1();
            //cast2();
            //cast3();
            //cast4();
            //cast5();
            //cast6();
            //doucovani();
            //doucovani2();
            //doucovani3();
            //doucovani4();
            //doucovani5();
            //doucovani6();
            doucovani7();
            Console.ReadLine();
        }
        private static void doucovani()
        {
            int[] poleLichych = new int[10];
            int[] poleSudych = new int[10];
            int pocetSudych = 0; int pocetLichych = 0;
            int cislo;
            while(pocetSudych <10 && pocetLichych <10)
            {
                try
                {
                    cislo = Convert.ToInt32(Console.ReadLine());
                    if (cislo == 0)
                        break;
                    else if (cislo % 2 == 0)
                    {
                        poleSudych[pocetSudych++] = cislo;
                    }
                    else
                    {
                        poleLichych[pocetLichych] = cislo;
                        pocetLichych++;
                    }
                }
                catch
                {
                    Console.WriteLine("Vložili jste cokoliv co není číslo");
                }
            }
            if(pocetSudych > pocetLichych)
            {
                int mezi = 0;
                for(int i = 0; i < poleSudych.Length && poleSudych[i] !=null; i++)
                {
                    mezi = mezi + poleSudych[i];
                }
                Console.WriteLine("Více čísel bylo sudých a jejich art soucet je: " + (mezi / pocetSudych));
            }
            else
            {
                int mezi = 0;
                for (int i = 0; i < poleLichych.Length && poleLichych[i] != null; i++)
                {
                    mezi += poleLichych[i];
                }
                Console.WriteLine("Více čísel bylo lichych a jejich art soucet je: " + (mezi / pocetLichych));
            }

        }
        private static void doucovani2()
        {
            string jmeno = "Lucinka";
            string jmenoObracene = "";
            int pocetZnaku = jmeno.Length -1;
            while(pocetZnaku>=0)
            {
                jmenoObracene += jmeno[pocetZnaku--];
            }
            Console.WriteLine(jmenoObracene);
        }
        private static void doucovani3()
        {
            int cislo = 421;

            if(cislo == 420)
                Console.WriteLine("Snad ne");
            else if(cislo ==421)
                Console.WriteLine("Ano pane Kuchař");
            switch (cislo)
            {
                case 420:
                    {
                        Console.WriteLine("Snad ne");
                        break;
                    }
                case 421:
                    {
                        Console.WriteLine("Ano pane Kuchař");
                        break;
                    }
            }
        }
        private static void doucovani4()
        {
            int[] poleCisel = new int[20];
            int cislo;
            int pocetCisel = 0;
            Random random = new Random();
            for (int i = 0; i < poleCisel.Length; i++)
            {
                cislo = random.Next(100) + 1;
                poleCisel[i] = cislo;
                if (cislo % 2 == 0 && cislo > 75)
                    Console.WriteLine(cislo);
            }
            while(pocetCisel<poleCisel.Length)
            {
                cislo = random.Next(100) + 1;
                poleCisel[pocetCisel] = cislo;
                if (cislo % 2 == 0 && cislo > 75)
                    Console.WriteLine(cislo);
                pocetCisel++;
            }
            pocetCisel = 0;
            do
            {
                cislo = random.Next(100) + 1;
                poleCisel[pocetCisel] = cislo;
                if (cislo % 2 == 0 && cislo > 75)
                    Console.WriteLine(cislo);
                pocetCisel++;
            } while (pocetCisel < poleCisel.Length);
        }
        private static void doucovani5()
        {
            string[] poleJmen = { "Tereza", "Jakub", "Matěj", "Jan", "Lucie" };
            Array.Sort(poleJmen);
            foreach (string p in poleJmen)
                Console.WriteLine(p);
            /*for (int i = 0; i < poleJmen.Length; i++)
                Console.WriteLine(poleJmen[i]);*/
            Console.ReadLine();
        }
        private static void doucovani6()
        {
            int cislo = 600;
            int[] delitele = new int[500];
            int pozice = 0;
            for (int i = 1; i < 600; i++)
            {
                if(cislo % i == 0)
                    delitele[pozice++] = i;
            }
            for(int i = 0; i < delitele.Length && delitele[i] != 0; i++)
                Console.Write(delitele[i] + ", ");
        }
        private static void doucovani7()
        {
            string[] mesice = { "Leden", "Únor", "Březen", "Duben", "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec" };
            int maxDelka = 0;
            for (int i = 0; i < mesice.Length; i++)
                if (maxDelka < mesice[i].Length)
                    maxDelka = mesice[i].Length;
            for (int j = 0; j < mesice.Length; j++)
                if (mesice[j].Length == maxDelka)
                    Console.WriteLine(mesice[j]);

        }
        private static void cast1()
        {
            int[] poleCisel = new int[10];
            Random nahoda = new Random();
            Console.Write("Nahodne generovane pole cisel ma hodnoty: ");
            for (int i = 0; i < poleCisel.Length; i++)
            {
                poleCisel[i] = nahoda.Next(20) + 1;
                Console.Write(poleCisel[i] + ", ");
            }
            int pocetCisel = 0;
            Console.WriteLine(" ");
            Console.Write("Všechny lichá čísla jsou: ");
            while (pocetCisel < poleCisel.Length)
            {
                if (poleCisel[pocetCisel] % 2 != 0)
                    Console.Write(poleCisel[pocetCisel] + ", ");
                pocetCisel++;
            }
        }
        private static void cast2()
        {
            string[] poleJmen = new string[15];
            int pocetVlozenychJmen = 0;
            string text = "";
            while (pocetVlozenychJmen < poleJmen.Length)
            {
                text = Console.ReadLine();
                if (text == "")
                    break;
                poleJmen[pocetVlozenychJmen] = text;
                pocetVlozenychJmen++;
            }
            Console.Clear();
            for (int i = 0; i < poleJmen.Length && poleJmen != null; i++)
                Console.WriteLine(poleJmen[i]);
        }
        private static void cast3()
        {
            //Program hodu kostou hodime kostku celkem 6x a budeme pocitat kolikrat padla 6.;
            int[] hodyKostkou = new int[50];
            int[] cisla = new int[6];
            Random random = new Random();
            for (int i = 0; i < hodyKostkou.Length; i++)
            {
                hodyKostkou[i] = random.Next(6) + 1;
                cisla[hodyKostkou[i]-1]++;
            }
            int max = cisla.Max();
            for (int i = 0; i < cisla.Length; i++)
                if (cisla[i] == max)
                    Console.Write((i + 1) + " ");
        }
        private static void cast4()
        {
            int[] pole = new int[10];
            for (int i = 0; i < pole.Length; i++)
                pole[i] = i + 1;
            int cislo = 0;
            while (cislo < pole.Length)
            {
                Console.WriteLine(pole[cislo]);
                cislo++;
            }
        }
        private static void cast5()
        {
            string jmeno = Console.ReadLine();
            int delkaJmena = jmeno.Length;
            Console.WriteLine(delkaJmena);
        }
        private static void cast6()
        {
            opakuj:
            try
            {
                int cislo = Convert.ToInt32(Console.ReadLine());
                if (cislo % 2 == 0)
                    Console.WriteLine("Číslo je sudé");
                else
                    Console.WriteLine("Číslo je liché");
            }
            catch
            {
                Console.WriteLine("Vložili jste nespravnou hodnotu nebylo to číslo");
                Thread.Sleep(5000);
                Console.Clear();
                goto opakuj;
            }

        }
    }
}