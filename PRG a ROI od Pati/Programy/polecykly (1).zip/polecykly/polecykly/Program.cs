﻿namespace polecykly
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //cast1();
            //cast2();
            cast3();
            //doucovani();
            //doucovani2();
            Console.ReadLine();
        }
        private static void doucovani()
        {
            int[] poleLichych = new int[10];
            int[] poleSudych = new int[10];
            int pocetSudych = 0; int pocetLichych = 0;
            int cislo;
            while(pocetSudych <10 && pocetLichych <10)
            {
                cislo = Convert.ToInt32(Console.ReadLine());
                if (cislo == 0)
                    break;
                else if (cislo % 2 == 0)
                {
                    poleSudych[pocetSudych++] = cislo;
                }
                else
                {
                    poleLichych[pocetLichych] = cislo;
                    pocetLichych++;
                }
            }
            if(pocetSudych > pocetLichych)
            {
                int mezi = 0;
                for(int i = 0; i < poleSudych.Length && poleSudych[i] !=null; i++)
                {
                    mezi = mezi + poleSudych[i];
                }
                Console.WriteLine("Více čísel bylo sudých a jejich art soucet je: " + (mezi / pocetSudych));
            }
            else
            {
                int mezi = 0;
                for (int i = 0; i < poleLichych.Length && poleLichych[i] != null; i++)
                {
                    mezi += poleLichych[i];
                }
                Console.WriteLine("Více čísel bylo lichych a jejich art soucet je: " + (mezi / pocetLichych));
            }

        }
        private static void doucovani2()
        {
            string jmeno = "Lucinka";
            string jmenoObracene = "";
            int pocetZnaku = jmeno.Length -1;
            while(pocetZnaku>=0)
            {
                jmenoObracene += jmeno[pocetZnaku--];
            }
            Console.WriteLine(jmenoObracene);
        }
        private static void cast1()
        {
            int[] poleCisel = new int[10]; //Vytvoření pole s názvem poleCisel tipu integer o velikosti 10
            Random nahoda = new Random(); //Vytvoření objektu třídy Random s názvem nahoda
            Console.Write("Nahodne generovane pole cisel ma hodnoty: ");
            for (int i = 0; i < poleCisel.Length; i++) //For cyklus s podmínkou nazačátku(vyvtoříme proměnnou i tipu integer o hodnotě 0; dokud i bude menší než velikost pole poleCisel (10); přičtení 1 k proměnné i
            {
                poleCisel[i] = nahoda.Next(20) + 1; //Do pole cisel na index/pozici o proměnné i vložíme náhodnou hodnotu 1-20
                Console.Write(poleCisel[i] + ", "); //Z pole cisel z indexu/pozice proměnné i vypíšeme uloženou hodnotu z řádku nahoře
            }
            int pocetCisel = 0;
            Console.WriteLine(" ");
            Console.Write("Všechny lichá čísla jsou: ");
            while (pocetCisel < poleCisel.Length)//While cyklus s podmínkou nazačátku(dokud proměnná pocetCisel je mensí než neý velikost pole poleCisel(10))
            {
                if (poleCisel[pocetCisel] % 2 != 0) //Pokud hodnota uložená v polyCisel na indexu/pozici pocetCisel je po dělení dvě se zbytek (neboli cislo je liché) tak podmínka je true
                    Console.Write(poleCisel[pocetCisel] + ", "); //Z pole cisel z indexu/pozice proměnné pocetCisel vypíšeme uloženou hodnotu z řádku nahoře
                pocetCisel++; //pocetCisel se zvětší o jedna
            }
        }
        private static void cast2()
        {
            string[] poleJmen = new string[15];
            int pocetVlozenychJmen = 0;
            string text = "";
            while (pocetVlozenychJmen < poleJmen.Length)
            {
                text = Console.ReadLine();
                if (text == "")
                    break;
                poleJmen[pocetVlozenychJmen] = text;
                pocetVlozenychJmen++;
            }
            Console.Clear();
            for (int i = 0; i < poleJmen.Length && poleJmen != null; i++)
                Console.WriteLine(poleJmen[i]);
        }
        private static void cast3()
        {
            //Program hodu kostou hodime kostku celkem 6x a budeme pocitat kolikrat padla 6.;
            int[] hodyKostkou = new int[6];
            int pocetSestek = 0;
            Random random = new Random();
            for (int i = 0; i < hodyKostkou.Length; i++)
            {
                hodyKostkou[i] = random.Next(6)+1;
                if (hodyKostkou[i] == 6) 
                    pocetSestek++;
            }
            Console.WriteLine("Šestka nám padla celkem " + pocetSestek + "krát");
        }
    }
}