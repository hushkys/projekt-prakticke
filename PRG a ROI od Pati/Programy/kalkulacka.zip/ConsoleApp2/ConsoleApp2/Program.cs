﻿namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a; int b; string znak;
            Console.WriteLine("Vložte dvě čísla a pak znak operace který s nimi chcete vykonat");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            znak = Console.ReadLine();

            switch(znak)
            {
                case "+":
                    {
                        Console.WriteLine("Součet čísel je: " + (a + b));
                        break;
                    }
                case "-":
                    {
                        Console.WriteLine("Rozdíl čísel je: " + (a - b));
                        break;
                    }
                case "*":
                    {
                        Console.WriteLine("Součin čísel je: " + (a * b));
                        break;
                    }
                case "/":
                    {
                        Console.WriteLine("Podík čísel je: " + (a / b));
                        break;
                    }
                    default:
                    {
                        Console.WriteLine("Zadali jste chybně znaménko");
                        break;
                    }
            }
        }
    }
}