﻿namespace polecykly
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //cast1();
            //cast2();

        }
        private static void cast1()
        {
            int[] poleCisel = new int[10];
            Random nahoda = new Random();
            Console.Write("Nahodne generovane pole cisel ma hodnoty: ");
            for (int i = 0; i < poleCisel.Length; i++)
            {
                poleCisel[i] = nahoda.Next(20) + 1;
                Console.Write(poleCisel[i] + ", ");
            }
            int pocetCisel = 0;
            Console.WriteLine(" ");
            Console.Write("Všechny lichá čísla jsou: ");
            while (pocetCisel < poleCisel.Length)
            {
                if (poleCisel[pocetCisel] % 2 != 0)
                    Console.Write(poleCisel[pocetCisel] + ", ");
                pocetCisel++;
            }
            Console.ReadLine();
        }
        private static void cast2()
        {
            string[] poleJmen = new string[15];
            int pocetVlozenychJmen = 0;
            string text = "";
            while (pocetVlozenychJmen < poleJmen.Length)
            {
                text = Console.ReadLine();
                if (text == "")
                    break;
                poleJmen[pocetVlozenychJmen] = text;
                pocetVlozenychJmen++;
            }
            Console.Clear();
            for (int i = 0; i < poleJmen.Length && poleJmen != null; i++)
                Console.WriteLine(poleJmen[i]);
        }
    }
}