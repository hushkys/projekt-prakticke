﻿namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int mesic = Convert.ToInt32(Console.ReadLine());
            opakovat:
            if(mesic > 12)
            {
                mesic = mesic - 12;
                goto opakovat;
            }
            else if(mesic < 1)
            {
                mesic = mesic + 12;
                goto opakovat;
            }
            switch(mesic)
            {
                case 1:
                    {
                        Console.WriteLine("Leden");
                        break;
                    }
                case 2:
                    {
                        Console.WriteLine("Únor");
                        break;
                    }
                case 3:
                    {
                        Console.WriteLine("Březen");
                        break;
                    }
                case 4:
                    {
                        Console.WriteLine("Duben");
                        break;
                    }
                case 5:
                    {
                        Console.WriteLine("Květen");
                        break;
                    }
                case 6:
                    {
                        Console.WriteLine("Červen");
                        break;
                    }
                case 7:
                    {
                        Console.WriteLine("Červenec");
                        break;
                    }
                case 8:
                    {
                        Console.WriteLine("Srpen");
                        break;
                    }
                case 9:
                    {
                        Console.WriteLine("Září");
                        break;
                    }
                case 10:
                    {
                        Console.WriteLine("Říjen");
                        break;
                    }
                case 11:
                    {
                        Console.WriteLine("Listopad");
                        break;
                    }
                case 12:
                    {
                        Console.WriteLine("Prosinec");
                        break;
                    }
            }
        }
    }
}