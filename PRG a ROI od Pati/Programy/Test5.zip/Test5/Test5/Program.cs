﻿using System.Drawing;

namespace Test5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TestA.vypisMaxMin(TestA.nactiCisla());
            TestB.vypisSudeCisla(TestB.nactiCisla());
            TestC.vypisDelkuRetezce(TestC.nactiText());
        }
        
    }
    static class TestA
    {
        public static double[] nactiCisla()
        {
            Console.WriteLine("Vkládejte postupně čísla se kterými následně budete chtít pracovat kdy pokud vložite 0 vkládání se ukončí");
            double[] poleCisel = new double[20];
            double cislo = 0;
            for(int i = 0; i < 20; i++)
            {
                cislo = Convert.ToDouble(Console.ReadLine());
                if (cislo == 0)
                    break;
                poleCisel[i] = cislo;
            }
            return poleCisel;
        }
        public static void vypisMaxMin(double[] poleCisel)
        {
            /*Array.Sort(poleCisel);
            int posledniCislo = 0;
            for(int i = poleCisel.Length-1; i>poleCisel.Length; i--)
                if (poleCisel[i] != 0)
                {
                    posledniCislo = i;
                    break;
                }
            Console.WriteLine(poleCisel[0] + poleCisel[posledniCislo]);*/
            double max = -99999999999;
            double min = 99999999999;
            for(int i = 0; i<poleCisel.Length; i++)
            {
                if (poleCisel[i] > max)
                    max = poleCisel[i];
                if (poleCisel[i] < min )
                    min = poleCisel[i];
            }
            Console.WriteLine(min + " " + max);
        }
    }
    static class TestB
    {
        public static double[] nactiCisla()
        {
            Console.WriteLine("Vkládejte postupně čísla se kterými následně budete chtít pracovat kdy pokud vložite 0 vkládání se ukončí");
            double[] poleCisel = new double[20];
            double cislo = 0;
            for (int i = 0; i < 20; i++)
            {
                cislo = Convert.ToDouble(Console.ReadLine());
                if (cislo == 0)
                    break;
                poleCisel[i] = cislo;
            }
            return poleCisel;
        }
        public static void vypisSudeCisla(double[] poleCisel)
        {
            Console.WriteLine("Všechna vložená sudá čísla jsou: ");
            for (int i = 0; i < poleCisel.Length && poleCisel[i] != 0 && poleCisel[i] % 2 == 0; i++)
            {
                Console.Write(poleCisel[i] + ", ");
            }
        }
    }
    static class TestC
    {
        public static string nactiText()
        {
            Console.WriteLine("Vložte textový řetezec se kterým budete chtít pracovat");
            return Console.ReadLine();
        }
        public static void vypisDelkuRetezce(string text)
        {
            Console.WriteLine("Delka řetezce je: " + text.Length);
        }
    }
}