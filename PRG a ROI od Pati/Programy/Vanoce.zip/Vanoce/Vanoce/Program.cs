﻿namespace Vanoce
{
    internal class Program
    {
        private static Random random = new Random();
        static void Main(string[] args)
        {
            Random random = new Random();
            //VeseleVanoce(); moje
            //VanoceHodina(); vytvořeno během hodiny 






        }
        private static void VanoceHodina()
        {
        zacatek:
            Console.Title = "Veselé Vánoce";
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Veselé vánoce");
            Console.WriteLine("");
            Console.WriteLine("Vyberte si velikost stromku");
            int velikostStromku = Convert.ToInt32(Console.ReadLine());
            Console.Clear();
            if (velikostStromku % 2 == 0)
                velikostStromku++;
            if (velikostStromku <= 10)
            {
                Console.WriteLine("Malá velikost stromku prosím znovu");
                Thread.Sleep(5000);
                Console.Clear();
                goto zacatek;
            }

            int stred = velikostStromku / 2;
            int mezi = 0;
            string[,] pole = new string[velikostStromku, (velikostStromku / 2) + 6];

            for (int i = 0; i < (velikostStromku / 2) + 4; i++)
            {
                for (int j = 0; j < velikostStromku; j++)
                {
                    if (stred - mezi <= j && j <= stred + mezi && i < velikostStromku / 2 && i == 0)
                    {
                        pole[j, i] = "*";
                    }
                    else if (stred - mezi <= j && j <= stred + mezi && i < velikostStromku / 2 && i != 0)
                    {
                        if (random.Next(1000) % 13 == 0)
                            pole[j, i] = "%";
                        else
                            pole[j, i] = "#";
                    }
                    else if (i > 2 - velikostStromku / 2 && stred - 1 <= j && j <= stred + 1 && i != 0)
                        pole[j, i] = "0";
                    else
                        pole[j, i] = " ";
                }
                mezi++;
            }

            Console.ForegroundColor = ConsoleColor.DarkGreen;
            for (int i = 0; i < 6 + velikostStromku / 2; i++)
            {
                for (int j = 0; j < velikostStromku; j++)
                {
                    if (pole[j, i] == "0")
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.Write(pole[j, i]);
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                    }
                    else if (pole[j, i] == "*")
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write(pole[j, i]);
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                    }
                    else if (pole[j, i] == "%")
                    {
                        mezi = random.Next(5) + 1;
                        switch (mezi)
                        {
                            case 1:
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    break;
                                }
                            case 2:
                                {
                                    Console.ForegroundColor = ConsoleColor.Blue;
                                    break;
                                }
                            case 3:
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    break;
                                }
                            case 4:
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;
                                    break;
                                }
                            case 5:
                                {
                                    Console.ForegroundColor = ConsoleColor.Gray;
                                    break;
                                }
                        }
                        Console.Write(pole[j, i]);
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                    }
                    else
                        Console.Write(pole[j, i]);
                }
                Console.WriteLine("");
            }
            Console.ReadLine();

        }
        private static void VeseleVanoce()
        {
            Console.Title = "Vesélé Vánoce";
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Veselé Vánoce");
            Console.WriteLine("");
            Console.WriteLine("Vyberte si velikost stromku");
            vytvorStromek(Convert.ToInt32(Console.ReadLine()));
            
        }
        private static void vytvorStromek(int sirka)
        {
            bool darky = false;
            Console.Clear();
            if (sirka % 2 == 0)
                sirka++;
            if(sirka<10)
            {
                Console.WriteLine("Malá velikost stromku prosím znovu");
                Thread.Sleep(5000);
                Console.Clear();
                VeseleVanoce();
            }    
            int stred = sirka / 2;
            int mezi = 0;
            string[,] pole = new string[sirka, (sirka/2)+6];
            for (int i = 0; i<(sirka/2)+4; i++)
            {
                for(int j = 0; j<sirka;j++)
                {
                    if (stred - mezi <= j && j <= stred + mezi && i < sirka / 2 && i == 0)
                        pole[j, i] = "*";
                    else if (stred - mezi <= j && j <= stred + mezi && i < sirka / 2 && i != 0)
                    {
                        if (random.Next(1000) % 13 == 0)
                            pole[j, i] = "%";
                        else
                            pole[j, i] = "#";
                    }
                    else if (i > 2 - sirka / 2 && stred - 1 <= j && j <= stred + 1 && i != 0)
                        pole[j, i] = "0";
                    else if(((i >  sirka /2 && j>0 && j<=5 && i!=0) || (i > sirka / 2 && j > sirka-7 && j < sirka-1 && i != 0)) && darky == true)
                        pole[j, i] = "&";
                    else
                        pole[j, i] = " ";
                }
                mezi++;
            }
            vypisStromek(pole,sirka,sirka);
        }
        private static void vypisStromek(string[,] pole,int sirka, int vyska)
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            for (int i = 0; i < 6+sirka/2; i++)
            {
                for (int j = 0; j < vyska; j++)
                {
                    if (pole[j, i] == "0")
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.Write(pole[j, i]);
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                    }
                    else if (pole[j, i] == "*")
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write(pole[j, i]);
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                    }
                    else if (pole[j, i] == "%")
                    {
                        int mezi = random.Next(5) + 1;
                        switch(mezi)
                            {
                            case 1:
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    break;
                                }
                            case 2:
                                {
                                    Console.ForegroundColor = ConsoleColor.Blue;
                                    break;
                                }
                            case 3:
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    break;
                                }
                            case 4:
                                {
                                    Console.ForegroundColor = ConsoleColor.Magenta;
                                    break;
                                }
                            case 5:
                                {
                                    Console.ForegroundColor = ConsoleColor.Gray;
                                    break;
                                }
                        }
                        Console.Write(pole[j, i]);
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                    }
                    else
                        Console.Write(pole[j, i]);
                }
                Console.WriteLine("");
            }
            Console.ReadLine();
        }
    }
}