﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PraceSeSoubory
{
    [Serializable]
    internal class Ukazka
    {
        private string text;
        private int cislo;
        public Ukazka(string text, int cislo)
        {
            this.text = text;
            this.cislo = cislo;
        }
    }
}
