﻿using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace PraceSeSoubory
{
    internal class Program
    {
        static BinaryFormatter formatter = new BinaryFormatter();
        static void Main(string[] args)
        {
            UlozText("Ahoj");
            Console.WriteLine(NactiText());
        }

        static void UlozText(string text) //Uložení jen textu
        {
            File.WriteAllText("file.txt",text);
        }
        static void UlozText(string[] text) //Uložení jednorozmerneho pole
        {
            string s = "";
            foreach (string t in text)
                s += t + ";"; //kdy ";" je rozdělovačem hodnot
            File.WriteAllText("file.txt", s);
        }
        static void UlozText(string[,] text) //Uložení jednorozmerneho pole
        {
            string s = "";
            for(int i = 0;i<text.GetLength(0);i++)
            {
                for (int j = 0; j < text.GetLength(1); j++)
                    s += text[i, j] + ";"; //kdy ";" je rozdělovačem hodnot jednoho řádku
                s += "|"; //kdy "|" je rozdělovačem řádků
            }
            File.WriteAllText("file.txt", s);
        }
        static void UlozObjekt(Ukazka ukazka)
        {
            using (FileStream stream = new FileStream("fileObjekt.txt", FileMode.Create))
            {
                formatter.Serialize(stream, ukazka);
            }
        }
        static string NactiText()
        {
            return File.ReadAllText("file.txt");
        }
        static string[] NactiTextPole()
        {
            return File.ReadAllText("file.txt").Split(';');
        }
        static string[,] NactiTextPole2D()
        {
            int j = 0;
            string[] mezi = File.ReadAllText("file.txt").Split('|');
            string[,] text = new string[mezi.Length, mezi[0].Split(';').Length];
            for(int i = 0;i<mezi.Length; i++)
            {
                foreach (string s in mezi[i].Split(';'))
                {
                    text[i, j++] = s;
                }
                j = 0;
            }

            return text;
        }
        static Ukazka NactiObjekt()
        {
            using (FileStream stream = new FileStream("fileObjekt.txt", FileMode.Open))
            {
                return (Ukazka)formatter.Deserialize(stream);
            }
        }
    }
}